var _xxcontent="this is secret";

alert('secret: ' + _xxsecret);
document.getElementById('sp1').innerHTML = _xxcontent;
//document.write(_xxcontent);
this.innerHTML = _xxcontent;


